package com.bookexplorer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookExplorerApplication {
    public static void main(String[] args) {
        SpringApplication.run(BookExplorerApplication.class, args);
    }
}
